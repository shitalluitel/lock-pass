if __name == '__main__':
	import main
    main()